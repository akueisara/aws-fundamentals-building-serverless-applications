var G_API_GATEWAY_URL_STR = null;
